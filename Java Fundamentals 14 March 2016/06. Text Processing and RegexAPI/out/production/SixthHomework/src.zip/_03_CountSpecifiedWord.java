import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class _03_CountSpecifiedWord {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String line = sc.nextLine().toLowerCase();
        String word = sc.next();
        int count = 0;
        int index = line.indexOf(word);
        while (index != -1) {
            if (index == 0) {
                if (line.charAt(index + 1) == ' ') {
                    count++;
                }
            } else if (index == (line.length() - 1)) {
                if (line.charAt(index - 1) == ' ') {
                    count++;
                }
            } else {
                if (line.charAt(index - 1) == ' ' && line.charAt(index + 1) == ' ' || line.charAt(index + 1) == '\'') {
                    count++;
                }
            }
            index = line.indexOf(word, index + 1);
        }
        System.out.println(count);
    }
}
